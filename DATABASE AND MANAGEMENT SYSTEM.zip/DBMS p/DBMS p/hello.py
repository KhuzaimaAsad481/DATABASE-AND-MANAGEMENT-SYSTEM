
from flask import Flask,render_template,request
from flask_mail import Mail,Message
import random
import password as p
vfcode=str(random.randint(100000,999999))
app=Flask(__name__)
app.config["MAIL_SERVER"]="smtp.gmail.com"
app.config["MAIL_PORT"]=465
app.config["MAIL_USE_SSL"]=True
app.config["MAIL_USERNAME"]="itsaaliraza@gmail.com"
app.config["MAIL_PASSWORD"]=p.password1
mail=Mail(app)
@app.route("/email",methods=["POST","GET"])
def sendvfcode():
    if request.method=="POST":
        email=request.form.get("email")
        print(email)
        msg = Message("VERIFICATION CODE",
                          sender="SEMESTERPROJECTMANAGMENTSYSTEM@gmail.com",
                          recipients=[email],
                          body="VERIFICATION CODE IS "+vfcode
                          )
        mail.send(msg)
    return render_template("verification.html")

app.run(debug=True)
